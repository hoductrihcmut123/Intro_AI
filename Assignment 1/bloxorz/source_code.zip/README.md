# Bloxorz Solver Using BFS and Genetic Algorithm
* Install pygame 
* Change option display value in main.py
* Run main.py
* Update later...